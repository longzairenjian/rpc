package com.lagou.service;

import java.io.IOException;

/**
 * 自定义序列化接口，Serializerion作为统一的序列化接口，
 * 无论何种方案都需要实现该接口
 * @author joker
 */
public interface Serializerion {

    /**
     * java对象转换为二进制
     *
     * @param object
     * @return
     */

    byte[] readObject(Object object) throws IOException;



    /**
     * 二进制转换成java对象
     *
     * @param clazz
     * @param bytes
     * @param <T>
     * @return
     */

    <T> T writeObject(Class<T> clazz, byte[] bytes) throws IOException;

}
