package com.lagou.service.impl;

import com.alibaba.fastjson.JSON;
import com.lagou.service.Serializerion;
import org.springframework.stereotype.Service;

@Service
public class JSONSerializer implements Serializerion {



    public byte[] readObject(Object object) {

        return JSON.toJSONBytes(object);

    }



    public <T> T writeObject(Class<T> clazz, byte[] bytes) {

        return JSON.parseObject(bytes, clazz);

    }

}
